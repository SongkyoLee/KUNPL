#include <iostream>
hello()
{
 std::cout<< "Hello, world" << std::endl;
 }
