 #include <stdio.h>
 
 int main(void)
 {
  printf("Audible or visual alert? \a\n");
  printf("Form feed. \f\n");
  printf("This escape, \r, moves the position to the first of the current line.\n");
  printf("Vertical tab /v is tricky, as its behavior is unspectified.\n");
  
   return 0;
 }
